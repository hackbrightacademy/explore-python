family_member1 = "Dillon"
family_member2 = "Angela"
family_member3 = "Kelsey"
family_member4 = "Luke"

length1 = len(family_member1)
length2 = len(family_member2)
length3 = len(family_member3)
length4 = len(family_member4)

print family_member1
print length1
print family_member2
print length2
print family_member3
print length3
print family_member4
print length4

new_family_member = raw_input("Enter the name of a new family member: ")
print "Great, so you added", new_family_member
print len(new_family_member)

