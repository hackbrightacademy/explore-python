# Create a new file called **module_1_printing.py**. In it, print a sentence of
# your choosing. Then, print the length of that sentence. Do this 3 more times.
# Next, print the only two boolean values that exist. Lastly, print the integer
# ``54321``, and then print it's Python type. Here is a sample output for the file
# that you will write.

print "Balloonicorn is going to a party this weekend!"
print len("Balloonicorn is going to a party this weekend!")
print "It's a birthday party."
print len("It's a birthday party.")
print "Balloonicorn needs to make a cake for her friend."
print len("Balloonicorn needs to make a cake for her friend.")
print "It will be red velvet."
print len("It will be red velvet.")

print True
print False

print 54321
print type(54321)